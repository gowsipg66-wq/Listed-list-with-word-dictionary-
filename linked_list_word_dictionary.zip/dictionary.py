class Node:
    def __init__(self, word, meaning):
        self.word = word
        self.meaning = meaning
        self.next = None


class WordDictionary:
    def __init__(self):
        self.head = None

    def add_word(self, word, meaning):
        new_node = Node(word, meaning)
        new_node.next = self.head
        self.head = new_node
        print("Word added successfully!")

    def search_word(self, word):
        temp = self.head
        while temp:
            if temp.word.lower() == word.lower():
                print("Meaning:", temp.meaning)
                return
            temp = temp.next
        print("Word not found!")

    def display_words(self):
        temp = self.head
        if temp is None:
            print("Dictionary is empty")
            return

        while temp:
            print(temp.word, "-", temp.meaning)
            temp = temp.next


dictionary = WordDictionary()

while True:
    print("\n--- WORD DICTIONARY ---")
    print("1. Add Word")
    print("2. Search Word")
    print("3. Display Words")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        word = input("Enter word: ")
        meaning = input("Enter meaning: ")
        dictionary.add_word(word, meaning)
    elif choice == "2":
        word = input("Enter word to search: ")
        dictionary.search_word(word)
    elif choice == "3":
        dictionary.display_words()
    elif choice == "4":
        print("Thank you!")
        break
    else:
        print("Invalid choice!")
